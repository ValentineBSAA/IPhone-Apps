Contains 16 approved game asset catalogs and 3 character pose catalogs prepared from the two user-supplied pictures.
